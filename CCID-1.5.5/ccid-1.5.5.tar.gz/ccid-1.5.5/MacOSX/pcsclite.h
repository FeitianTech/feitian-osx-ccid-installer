#include <PCSC/pcsclite.h>
#include <PCSC/wintypes.h>
